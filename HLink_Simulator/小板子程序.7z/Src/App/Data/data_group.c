
/***********************************************************************
@file   : data_group.c
@brief  : 
@note	: Copyright(C) 2023 JCH Appliances, Inc. All Rights Reserved.
@note   : 与组控器的数据交互
************************************************************************/
#include "data_group.h"





















