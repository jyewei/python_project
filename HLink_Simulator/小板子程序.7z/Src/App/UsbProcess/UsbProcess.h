#ifndef __USBPROCESS_H
#define __USBPROCESS_H
#include "Common.h"






void UsbProcess(uint8_t taskNo,uint8_t flag_init);


#endif//__USBPROCESS_H
