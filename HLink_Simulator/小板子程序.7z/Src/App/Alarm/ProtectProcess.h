#ifndef __PROTECTPROCESS_H
#define __PROTECTPROCESS_H
#include "common.h"







void ProtectProcess(uint8_t taskNo,uint8_t flag_init);

#endif//__PROTECTPROCESS_H
