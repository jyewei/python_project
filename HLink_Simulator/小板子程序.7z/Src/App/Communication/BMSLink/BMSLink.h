#ifndef __BMSLINK_H
#define __BMSLINK_H
#include "common.h"





void BMSLink(uint8_t taskNo,uint8_t flag_init);



#endif//__BMSLINK_H
