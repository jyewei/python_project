#ifndef __THERMOSTATLINK_H
#define __THERMOSTATLINK_H
#include "common.h"







void ThermostatLink(uint8_t taskNo,uint8_t flag_init);

#endif//__THERMOSTATLINK_H
