#ifndef __CHILLERSLAVE_H
#define __CHILLERSLAVE_H
#include "common.h"







void ChillerSlaveLink(uint8_t taskNo,uint8_t flag_init);

#endif//__CHILLERSLAVE_H
