/***********************************************************************
@file   : CompLink.c
@brief  : 
@author : yanxin.zuo
@version: v1.0
@data	: 2023-4-3
@note	: Copyright(C) 2023 JCH Appliances, Inc. All Rights Reserved.
************************************************************************/
#include "CompLink.h"



/************************************************************************
@name  	: CompLinkHandle
@brief 	: 
@param 	: None
@return	: None
*************************************************************************/
void CompLinkHandle(void)
{

	
}
