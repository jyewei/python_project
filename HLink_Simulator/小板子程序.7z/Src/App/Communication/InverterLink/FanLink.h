#ifndef __FANLINK_H
#define __FANLINK_H
#include "common.h"







void FanLinkHandle(void);

#endif//__FANLINK_H
