#ifndef __COMPLINK_H
#define __COMPLINK_H
#include "common.h"







void CompLinkHandle(void);


#endif//__COMPLINK_H
