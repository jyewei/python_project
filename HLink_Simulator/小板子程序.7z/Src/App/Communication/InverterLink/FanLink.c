/***********************************************************************
@file   : FanLink.c
@brief  : 
@note	: Copyright(C) 2023 JCH Appliances, Inc. All Rights Reserved.
************************************************************************/
#include "FanLink.h"



/************************************************************************
@name  	: FanLinkHandle
@brief 	: 
@param 	: None
@return	: None
*************************************************************************/
void FanLinkHandle(void)
{


}
