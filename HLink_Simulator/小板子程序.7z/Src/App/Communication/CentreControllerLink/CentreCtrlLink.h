#ifndef __CENTRECTRLLINK_H
#define __CENTRECTRLLINK_H
#include "Common.h"





void CentreCtrlLink(uint8_t taskNo,uint8_t flag_init);



#endif//__CENTRECTRLLINK_H
