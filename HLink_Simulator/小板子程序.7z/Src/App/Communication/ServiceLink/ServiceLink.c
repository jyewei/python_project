/***********************************************************************
@file   : ServiceLink.c
@brief  : 
@note	: Copyright(C) 2023 JCH Appliances, Inc. All Rights Reserved.
************************************************************************/
#include "ServiceLink.h"
#include "safety_function.h"
#include "modbus.h"
#include "TimerCounter.h"
#include "ChillerLinkData.h"

uint8_t flag_send = FALSE;



/************************************************************************
@name  	: ServiceLinkTransmit
@brief 	: 
@param 	: None
@return	: None
*************************************************************************/
void ServiceLinkTransmit(void)
{
    uint8_t tx_status;
    uint16_t i;
    
    tx_status = RsCheckTxStatus(RS_CH_SERVICE);
    if (tx_status == FALSE)//没有正在发送
    {
        if (flag_send == TRUE)
        {
            flag_send = FALSE;
            
         
            
                for(i = 0;i < RsRxTx[0].tx_len;i++)
                {
                    RsTxBuf[RS_CH_SERVICE][i] = RsRxTx[0].rx_buf[i];
                    
                }
                //RsSend(RS_CH_SERVICE);
                StartSendData(0,RsTxBuf[RS_CH_SERVICE],i);
                
                
                
            
            
        }
    }
}


/************************************************************************
@name  	: ServiceLinkReceive
@brief 	: 
@param 	: None
@return	: None
*************************************************************************/
void ServiceLinkReceive(void)
{
    flag_send = TRUE;
}

/************************************************************************
@name  	: ServiceLink
@brief 	: 
@param 	: None
@return	: None
*************************************************************************/
void ServiceLink(uint8_t taskNo,uint8_t flag_init)
{
    uint16_t bcc=0;
    uint16_t i;
    uint8_t *buf;
    uint16_t len;
    uint16_t *pdat;
    SFSetRunTaskNo( taskNo );
	if (flag_init) //init
    {
        
    }
    if (RsCheckTxStatus(RS_CH_SERVICE)==FALSE)
    {
        if(flag_send==TRUE)
        {
            flag_send=FALSE;
            StartSendData(0,buf,3);
        }
        
    }
    if ((TimerCheck(NO_SERVERlLINK1_TIMEOUT) == TRUE) && (RsRxTx[0].rx_cnt))
    {
        buf[0]=RsRxTx[0].rx_buf[0];
        for (i = 1; i < RsRxTx[0].rx_cnt; i++)
        {			
               bcc ^= RsRxTx[0].rx_buf[i];
               buf[i]=RsRxTx[0].rx_buf[i];
        }
        if(bcc==0)
        {
            RsRxTx[0].tx_len = RsRxTx[0].rx_cnt;
            RsRxTx[0].rx_cnt = 0;
            switch (buf[7])
            {
            case 0xA8:
                    switch (buf[8])
                {
                    case 0x21: 
                                pdat = &table[buf[4]].unit_init.dsw1.word;
                                len = sizeof(UnitTableInitType)/sizeof(uint16_t);
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;     
                        break;
                    case 0x22: 
                                pdat = &table[buf[4]].unit_event.state.word;
                                len = sizeof(UnitTableEventType)/sizeof(uint16_t);
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }                   
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;
                        break;               
                    case 0x25: 
                                pdat = &table[buf[4]].unit_io.DIO.word;
                                len = 14;
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }                   
                                table[buf[4]].unit_io.power_sum=(((uint32_t)((uint16_t)buf[41]<<8)|buf[42])<<16)|(((uint16_t)buf[39]<<8)|buf[40]);
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;                           
                        break;
                    case 0x27: 
                                pdat = &table[buf[4]].unit_alarmh.total_num;
                                len = sizeof(UnitTableAlarmType)/sizeof(uint16_t);
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }                   
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;                           
                        break;
                    case 0x42: 
                    
                                pdat = &table[buf[4]].cycle[0].event.state1.word;
                                len = sizeof(CycleTableEventType)/sizeof(uint16_t);
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }                   
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;           
                        break;
                    case 0x52:   
                                pdat = &table[buf[4]].cycle[1].event.state1.word;
                                len = sizeof(CycleTableEventType)/sizeof(uint16_t);
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }    
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;    
                        break;
                    case 0x62:    
                                pdat = &table[buf[4]].cycle[2].event.state1.word;
                                len = sizeof(CycleTableEventType)/sizeof(uint16_t);
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }    
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;     
                        break;
                    case 0x72:    
                                pdat = &table[buf[4]].cycle[3].event.state1.word;
                                len = sizeof(CycleTableEventType)/sizeof(uint16_t);
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }    
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;     
                        break;
                    case 0x45:    
                                pdat = &table[buf[4]].cycle[0].io.io1.word;
                                len = sizeof(CycleTableIOType)/sizeof(uint16_t);
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }    
                                
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;
                        break;
                    case 0x55: 
                                pdat = &table[buf[4]].cycle[1].io.io1.word;
                                len = sizeof(CycleTableIOType)/sizeof(uint16_t);
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }    
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;
                        break;
                    case 0x65:
                                pdat = &table[buf[4]].cycle[2].io.io1.word;
                                len = sizeof(CycleTableIOType)/sizeof(uint16_t);
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }    
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;
                        break;
                    case 0x75:
                                pdat = &table[buf[4]].cycle[3].io.io1.word;
                                len = sizeof(CycleTableIOType)/sizeof(uint16_t);
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }    
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;
                        break;
                    case 0x44:
                                pdat = &table[buf[4]].cycle[0].init_sum.comp_romNO;
                                len = 2;
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }
                                table[buf[4]].cycle[0].init_sum.comp_run_time_sum=(((uint32_t)((uint16_t)buf[15]<<8)|buf[16])<<16)|(((uint16_t)buf[17]<<8)|buf[18]);
                                table[buf[4]].cycle[0].init_sum.comp_power_sum=(((uint32_t)((uint16_t)buf[19]<<8)|buf[20])<<16)|(((uint16_t)buf[21]<<8)|buf[22]);
                                table[buf[4]].cycle[0].init_sum.sys_run_time_sum=(((uint32_t)((uint16_t)buf[23]<<8)|buf[24])<<16)|(((uint16_t)buf[25]<<8)|buf[26]);    
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;
                        break;
                    case 0x54:
                                pdat = &table[buf[4]].cycle[1].init_sum.comp_romNO;
                                len = 2;
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }
                                table[buf[4]].cycle[1].init_sum.comp_run_time_sum=(((uint32_t)((uint16_t)buf[15]<<8)|buf[16])<<16)|(((uint16_t)buf[17]<<8)|buf[18]);
                                table[buf[4]].cycle[1].init_sum.comp_power_sum=(((uint32_t)((uint16_t)buf[19]<<8)|buf[20])<<16)|(((uint16_t)buf[21]<<8)|buf[22]);
                                table[buf[4]].cycle[1].init_sum.sys_run_time_sum=(((uint32_t)((uint16_t)buf[23]<<8)|buf[24])<<16)|(((uint16_t)buf[25]<<8)|buf[26]);
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;
                        break;
                    case 0x64:
                                pdat = &table[buf[4]].cycle[2].init_sum.comp_romNO;
                                len = 2;
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }
                                table[buf[4]].cycle[2].init_sum.comp_run_time_sum=(((uint32_t)((uint16_t)buf[15]<<8)|buf[16])<<16)|(((uint16_t)buf[17]<<8)|buf[18]);
                                table[buf[4]].cycle[2].init_sum.comp_power_sum=(((uint32_t)((uint16_t)buf[19]<<8)|buf[20])<<16)|(((uint16_t)buf[21]<<8)|buf[22]);
                                table[buf[4]].cycle[2].init_sum.sys_run_time_sum=(((uint32_t)((uint16_t)buf[23]<<8)|buf[24])<<16)|(((uint16_t)buf[25]<<8)|buf[26]);
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;
                        break;
                    case 0x74:
                                pdat = &table[buf[4]].cycle[3].init_sum.comp_romNO;
                                len = 2;
                                for(i=0;i<len;i++)
                                {
                                    *(pdat+i) = ((uint16_t)buf[11+i*2] << 8) | buf[12+i*2]; 
                                }
                                table[buf[4]].cycle[3].init_sum.comp_run_time_sum=(((uint32_t)((uint16_t)buf[15]<<8)|buf[16])<<16)|(((uint16_t)buf[17]<<8)|buf[18]);
                                table[buf[4]].cycle[3].init_sum.comp_power_sum=(((uint32_t)((uint16_t)buf[19]<<8)|buf[20])<<16)|(((uint16_t)buf[21]<<8)|buf[22]);
                                table[buf[4]].cycle[3].init_sum.sys_run_time_sum=(((uint32_t)((uint16_t)buf[23]<<8)|buf[24])<<16)|(((uint16_t)buf[25]<<8)|buf[26]);
                                buf[0]=0x22;buf[1]=0x06;buf[2]=buf[4];
                                flag_send=TRUE;
                        break;

                    default:      
                        break;
                }
                break;
            
            default:
                break;
            }
            
        }
        else
        {
            RsRxTx[0].tx_len = RsRxTx[0].rx_cnt;
            RsRxTx[0].rx_cnt = 0;
        } 
    }    
}
