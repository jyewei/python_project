#ifndef __SERVICELINK_H
#define __SERVICELINK_H
#include "common.h"







void ServiceLink(uint8_t taskNo,uint8_t flag_init);
extern uint8_t flag_send;
#endif//__SERVICELINK_H
