#ifndef __GROUPLINK_H
#define __GROUPLINK_H
#include "common.h"




void GroupLink(uint8_t taskNo,uint8_t flag_init);



#endif//__GROUPLINK_H
