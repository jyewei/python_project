#ifndef __EEPROMPROCESS_H
#define __EEPROMPROCESS_H
#include "common.h"




































void EepromProcess(uint8_t taskNo,uint8_t flag_init);

#endif//__EEPROMPROCESS_H
