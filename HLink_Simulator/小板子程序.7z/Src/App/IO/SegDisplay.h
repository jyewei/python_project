#ifndef __SEGDISPLAY_H
#define __SEGDISPLAY_H
#include "Common.h"







void SegDisplay(void);

#endif//__SEGDISPLAY_H
