/***********************************************************************
@file   : SegDisplay.c
@brief  : 
@author : yanxin.zuo
@version: v1.0
@data	: 2023-4-3
@note	: Copyright(C) 2023 JCH Appliances, Inc. All Rights Reserved.
************************************************************************/
#include "SegDisplay.h"



/************************************************************************
@name  	: SegDisplay
@brief 	: 
@param 	: None
@return	: None
*************************************************************************/
void SegDisplay(void)
{

	

}
