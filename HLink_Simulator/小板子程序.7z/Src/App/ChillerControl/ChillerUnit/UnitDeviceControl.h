#ifndef __UNITDEVICECONTROL_H
#define __UNITDEVICECONTROL_H
#include "Common.h"









void UnitChassisHeatBeltControl(uint8_t state);
void UnitBoardExchangeHeatBeltControl(uint8_t state);



#endif//__UNITDEVICECONTROL_H
