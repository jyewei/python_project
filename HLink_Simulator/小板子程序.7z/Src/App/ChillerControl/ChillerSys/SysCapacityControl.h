#ifndef __CAPACITYCONTROL_H
#define __CAPACITYCONTROL_H
#include "Common.h"

















void SysCapacityControlTimerCounter(void);
void SysCapacityControl(void);







#endif//__CAPACITYCONTROL_H
