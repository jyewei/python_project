#ifndef __ANTIFREEZECONTROL_H
#define __ANTIFREEZECONTROL_H
#include "Common.h"










uint8_t CheckSysAntifreezeRequire(void);




#endif//__ANTIFREEZECONTROL_H
