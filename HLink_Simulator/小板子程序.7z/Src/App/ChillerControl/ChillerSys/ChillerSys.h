#ifndef __CHILLERSYS_H
#define __CHILLERSYS_H
#include "common.h"











void ChillerSysInit(void);
void ChillerSysControl(void);




#endif//__CHILLERSYS_H
