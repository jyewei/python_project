#ifndef __CHILLERCYCLE_H
#define __CHILLERCYCLE_H
#include "common.h"








void ChillerCycleInit(uint8_t cycle);
void ChillerCycleControl(uint8_t ch);


#endif//__CHILLERCYCLE_H
