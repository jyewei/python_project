#ifndef __EXPVCONTROL_H
#define __EXPVCONTROL_H
#include "common.h"













void ExpvInit(uint8_t cycle);
void ExpvControl(uint8_t cycle);



#endif//__EXPVCONTROL_H
