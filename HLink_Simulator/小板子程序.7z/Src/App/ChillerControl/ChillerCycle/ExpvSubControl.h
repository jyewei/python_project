#ifndef __EXPVCSUBCONTROL_H
#define __EXPVCSUBCONTROL_H
#include "common.h"

















uint8_t GetExpvSubInitStepKeep(uint8_t cycle);
uint8_t GetExpvSubNormalCloseState(uint8_t cycle);
void ExpvSubStatusControl(uint8_t cycle);






#endif//__EXPVCSUBCONTROL_H
