#ifndef __CHILLERPROCESS_H
#define __CHILLERPROCESS_H
#include "common.h"







void ChillerProcess(uint8_t taskNo,uint8_t flag_init);


#endif//__CHILLERPROCESS_H
