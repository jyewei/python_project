#ifndef __RESET_H
#define __RESET_H
#include "Common.h"











void Reset(void);



#endif//__RESET_H
