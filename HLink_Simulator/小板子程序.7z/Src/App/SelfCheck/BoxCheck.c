/***********************************************************************
@file   : BoxCheck.c
@brief  : 
@note	: Copyright(C) 2023 JCH Appliances, Inc. All Rights Reserved.
************************************************************************/
#include "BoxCheck.h"
#include "safety_function.h"


/************************************************************************
@name  	: BoxCheck
@brief 	: 
@param 	: None
@return	: None
*************************************************************************/
void BoxCheck(uint8_t taskNo,uint8_t flag_init)
{
    SFSetRunTaskNo( taskNo );
	

}
