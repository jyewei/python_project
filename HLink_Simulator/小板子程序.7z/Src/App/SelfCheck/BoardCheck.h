#ifndef __BOARDCHECK_H
#define __BOARDCHECK_H
#include "Common.h"







void BoardCheck(uint8_t taskNo,uint8_t flag_init);

#endif//__BOARDCHECK_H
