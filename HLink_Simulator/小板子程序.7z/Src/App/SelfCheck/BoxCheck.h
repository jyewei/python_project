#ifndef __BOXCHECK_H
#define __BOXCHECK_H
#include "Common.h"







void BoxCheck(uint8_t taskNo,uint8_t flag_init);

#endif//__BOXCHECK_H
