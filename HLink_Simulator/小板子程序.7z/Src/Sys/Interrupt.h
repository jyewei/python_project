#ifndef __INTERRUPT_H__
#define __INTERRUPT_H__








void r_sci0_transmitend_interrupt(void);
void r_sci0_receiveerror_interrupt(void);
void r_sci1_transmitend_interrupt(void);
void r_sci1_receiveerror_interrupt(void);
void r_sci2_transmitend_interrupt(void);
void r_sci3_transmitend_interrupt(void);
void r_sci3_receiveerror_interrupt(void);


#endif	// __INPUTINTERRUPT_H__


