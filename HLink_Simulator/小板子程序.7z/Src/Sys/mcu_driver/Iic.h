#ifndef __IIC_H
#define __IIC_H
#include "Common.h"
#include "iodefine.h"









#endif//__WDT_H
