#ifndef __WDT_H
#define __WDT_H
#include "Common.h"
#include "iodefine.h"





void WdtRestart(void);


#endif//__WDT_H
